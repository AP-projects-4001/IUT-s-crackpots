#include "good.h"

good::good()
{

}

void good::setId(int id)
{
    this->id = id;
}

int good::getId()
{
    return id;
}

void good::setName(std::string name)
{
    this->name = name;
}

std::string good::getName() {
    return name;
}

void good::setPrice(int price) {
    this->price = price;
}

int good::getPrice() {
    return price;
}

void good::setRemainingNum(int remainingNum) {
    this->remainingNum = remainingNum;
}

int good::getRemainingNum() {
    return remainingNum;
}

void good::setBoughtNum(int boughtNum) {
    this->boughtNum = boughtNum;
}

int good::getBoughtNum() {
    return boughtNum;
}

void good::getGoods() {

}

void good::insert() {

}





