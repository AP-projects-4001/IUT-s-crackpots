#ifndef CATEGORIES_H
#define CATEGORIES_H
#include "string"

#include "good.h"

class categories : public good
{
public:
    categories();
};

#endif // CATEGORIES_H
