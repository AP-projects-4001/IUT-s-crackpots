#include "categories.h"
#include "fstream"
#include <vector>

using namespace std;

categories::categories()
{

}
